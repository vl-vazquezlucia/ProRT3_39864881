<?php 

use CodeIgniter\Router\RouteCollection;

$routes->get('/registro', usuario_controller::create');
$routes->get('principal.php','usuario_controller::principal');
$routes->get('acerca_de.php', 'Home::acerca_de.php');
$routes->get('catalogo.php', 'Home::catalogo.php');
$routes->get('registro.php', 'Home::registro.php');
$routes->get('login.php','Home::login.php');

/*Rutas del registro de usuarios*/
$routes->get('/registro.php','usuario_controller::create');
$routes->post('/enviar-form','usuario_controller::formValidation');

/*Rutas para el login*/
$routes->get('/login.php', 'login_controller');
$routes->post('/enviarlogin','login_controller::formValidation');
$routes->get('/panel', 'panel_controller::index',['filter'=>'auth']);
$routes->get('logout', 'login_controller::logout');

