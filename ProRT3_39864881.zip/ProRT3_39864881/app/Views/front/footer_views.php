<footer class="foter"> 
    <div class="footer-content">
	<div class="social-icons">
      <p>Síganos en nuestras redes sociales para ver todos nuestros productos y nuestras promociones.</p>
      <a href="#"><img src="C:/Users/Netbook/Users/Desktop/ProT3_39864881/assets/img/facebook.png" alt="Facebook" width="50" height="50"/></a>
        <a href="#"><img src="C:/Users/Netbook/Users/Desktop/ProT3_39864881/assets/img/instagram.jpg" alt="Instagram" width="50" height="50"/></a>
        <div>
		</div>
      
      </div>
    </div>
    <p class="texto2" id="copyright">Derechos de autor© Vazquez Lucia 2024| Mi página web. Todos los derechos reservados.</p>
  </footer>
  <script src="assets/js/boostrap.bundle.min.js"></script>
  <script src= "https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"  integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>