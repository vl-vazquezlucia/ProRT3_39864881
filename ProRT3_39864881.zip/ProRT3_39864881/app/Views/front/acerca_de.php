<!--Nuestro chef-presentacion-->
<div class="card">
        <img src="assets/img/chef.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Acerca de nosotros</h5>
          <p class="card-text">Juan Pérez Fundador y Chef Ejecutivo Con más de 15 años de experiencia, lidera nuestra cocina con creatividad y pasión por la calidad de nuestros productos.</p>
          <p>Nos encontramos en 9 de Julio al 345 y por calle Mendoza al 1041.Corrientes Capital.</p>
          <a href="#" class="btn btn-primary">Conoce nuestras ubicaciones</a>
        </div>
      </div>
    </div>