<?php

namespace App\Controllers;

class Home extends BaseController
{
           public function index(){
                $data['titulo'] = 'pagina principal';
                echo view('front/head_views.php',$data);
                echo view('front/navbar_views.php');
                echo view('front/principal.php');
                echo view('front/footer_view');
	}

        public function principal(){
                $data['titulo'] = 'Principal.php';
                echo view('fron/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/principal.php');
                echo view('front/footer.php');
                
        }

	public function quienes_somos(){
                $data['titulo'] = '¿Quienes Somos?';
                echo view('front/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/quienes_somos.php');
                echo view('front/footer.php');
                
        }

        public function acerca_de(){
                $data['titulo'] = 'acerca_de.php';
                echo view('front/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/acerca_de,php');
                echo view('front/footer.php');
                
        }

        public function catalogo(){
                $data['titulo'] = 'catalogo.php';
                echo view('front/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/catalogo.php');
                echo view('front/footer.php');
                
        }

        public function registro(){
                $data['titulo'] = 'Registro.php';
                echo view('front/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/usuario/registro.php');
				echo view ('front/footer.php');
              
        }

        public function login(){
                $data['titulo'] = 'login.php';
                echo view('front/head_views.php', $data);
                echo view('front/navbar_views.php');
                echo view('front/usuario/login.php');
				echo view('front/footer.php');
        }