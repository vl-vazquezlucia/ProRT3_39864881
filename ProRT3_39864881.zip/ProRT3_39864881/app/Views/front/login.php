<div class ="conteiner mt-5 mb-5 d-flex justify-content-center">
 <div class="card" style="width: 50%;">
  <div class="card-header text-center">
   <h2>Iniciar sesion</h2>
   </div>
<!--mensaje de error--->
<?php if(session()->getFlashdata('msg'));?>
 <div class="alert alert-warning">
  <?= session()->getFlashdata('msg')?>
  </div>
 <?php endif;?>
 
 <!--inicio de formulario login--->
 <form method="post" action="<?php echo base_url('/enviarlogin') ?>">
        <div class="card-body" "media="(max-width:768px)">
		<div class="mb-2">
        <label for="exampleFormControlInput1" class="form-label">Correo</label>
        <input name="email" type="text" class="form-control" placeholder="correo">
        </div>
		
	    <div class="mb-3">
        <label for="examenFormControlInput1" class="form-label">Password</label>
        <input type="pass" type="password" class="form-control" placeholder="contraseña">
	    </div>
		
		<input type="submit" value="ingresar" class="btn btn-success">
		<a href="<?php echo base_url('login'); ?>" class="btn btn-danger">Cancelar</a>
	    <br><span>¿Aún no se ha registró? <a href="<?php echo base_url('/registro'); ?>">
        Registrese aqui</a></span> 
		
        <button type="button" class="btn btn-success">Ingresar</button>
        <button type="button" class="btn btn-danger">Cancelar</button>
        
        </div>		
		</div>
          </form>
        