 <div class="card mb-4">
        <div class="card-body">
          <h5 class="card-title">Iniciar sesión</h5>
          <form>
            <div class="mb-3">
              <label for="loginEmail" class="form-label">Correo electrónico</label>
              <input type="email" class="form-control" id="loginEmail" name="email">
            </div>
			<div class="mb-3">
              <label for="registroPassword" class="form-label">Password</label>
              <input type="password" class="form-control" id="registroPassword" name="password">
			  </div>
            <button type="button" class="btn btn-success">Ingresar</button>
            <button type="button" class="btn btn-danger">Cancelar</button>
          </form>
          
  </div>
</div>