<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\usuario_Model;

class panel_controller extends Controller
 {
    public function index() {
        $model = new Usuario_Model();
        $data['usuarios'] = $model->where('baja', 'NO')->findAll();

        $session = session();
        $nombre = $session->get('usuario'); 
        $perfil = $session->get('perfil_id');

        $data['perfil_id'] = $perfil;
        
		$dato['titulo'] = 'Panel del Usuario'; 
		echo view('front/head_views',$data);
		echo view('front/navbar_views',$data);
		echo view('back/usuario/usuario_logueado',$data);
		echo view('front/footer_views');
        $model = new usuario_Model();
        $usuarios = $model->getUsuarios();
        

        //head y nav
        echo view('front/head_view', $dato); 
        echo view('front/navbar_view');

            // Vista Admin
                if ($perfil == 1) {

                    
                echo view ('Back/usuario/usuario_logueado', $data);  

                echo view('Back/usuario/panel_admin', compact('usuarios')); 
               




            // Vista para cliente 
                } elseif ($perfil == 2) {


                
                    $data['perfil_id']= $perfil;

                    $dato['titulo']='panel del usuario'; 
            
        
                    echo view ('Back/usuario/usuario_logueado', $data); 
            
            }

        echo view('front/footer_view');
    }

} 