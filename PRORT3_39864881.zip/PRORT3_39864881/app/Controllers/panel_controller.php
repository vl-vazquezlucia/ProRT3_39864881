<?php
namespace App\Controllers;
Use CodeIgniter\Controller;

class panel_controller extends Controller{
    
    public function index(){
        $session = session();
        $nombre = $session->get('usuario');
        $perfil = $session->get('perfil_id');

        $data['perfil_id'] = $perfil;

        $dato['titulo'] = 'Panel del Usuario';
        echo view('front/head_view', $dato);
        echo view('front/navbar_view');
        echo view('front/principal', $data);
        echo view('front/footer_view');
    }
}