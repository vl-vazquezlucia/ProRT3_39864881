<div class="container mt-5 mb-5 d-flex justify-content-center">
  <div class="card" style="max-width: 500px; width: 100%;">
    <div class="card-header text-center bg-primary text-white">
      <h2>Iniciar sesión</h2>
    </div>

    <!-- Mensaje de error -->
    <?php if (session()->getFlashdata('msg')): ?>
      <div class="alert alert-warning m-3">
        <?= session()->getFlashdata('msg') ?>
      </div>
    <?php endif; ?>

    <!-- Inicio de formulario login -->
    <form method="post" action="<?= base_url('/enviarlogin') ?>">
      <div class="card-body">
        <div class="mb-3">
          <label for="email" class="form-label">Correo</label>
          <input name="email" type="email" class="form-control" placeholder="correo@ejemplo.com" required>
        </div>

        <div class="mb-3">
          <label for="pass" class="form-label">Password</label>
          <input name="pass" type="password" class="form-control" placeholder="Contraseña" required>
        </div>

        <div class="d-grid gap-2">
          <input type="submit" value="Ingresar" class="btn btn-success">
          <a href="<?= base_url('login'); ?>" class="btn btn-danger">Cancelar</a>
        </div>
        <div class="text-center mt-3">
          <span>¿Aún no se ha registrado? <a href="<?= base_url('/registro'); ?>">Regístrese aquí</a></span>
        </div>
      </div>
    </form>
  </div>
</div>
